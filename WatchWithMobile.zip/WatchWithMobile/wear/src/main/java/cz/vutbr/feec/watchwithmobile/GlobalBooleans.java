package cz.vutbr.feec.watchwithmobile;

public class GlobalBooleans
{
    public static boolean firstComDone=false;
    public static boolean secondComDone=false;

}
