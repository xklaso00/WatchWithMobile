package cz.vutbr.feec.watchwithmobile;

import android.util.Log;

import org.spongycastle.jce.ECNamedCurveTable;
import org.spongycastle.jce.spec.ECParameterSpec;
import org.spongycastle.math.ec.ECCurve;
import org.spongycastle.math.ec.ECPoint;

import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.Security;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;
import java.util.Arrays;

public class Test {
    public static String TAG="TEST";
    public void doSth() throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {
        ECParameterSpec ecSpec = ECNamedCurveTable.getParameterSpec("secp224r1");
        ECCurve curve = ecSpec.getCurve();
        BigInteger Gx= new BigInteger("B70E0CBD6BB4BF7F321390B94A03C1D356C21122343280D6115C1D21", 16);
        BigInteger Gy= new BigInteger("BD376388B5F723FB4C22DFE6CD4375A05A07476444D5819985007E34", 16);
        ECPoint G = curve.createPoint(Gx,Gy);


        /*Security.insertProviderAt(new org.spongycastle.jce.provider.BouncyCastleProvider(), 1);
        KeyPairGenerator g = KeyPairGenerator.getInstance("EC");
        g.initialize(new ECGenParameterSpec("secp224r1"), new SecureRandom());
        KeyPair aKeyPair = g.generateKeyPair();
        ECPrivateKey SecKeyA= (ECPrivateKey)aKeyPair.getPrivate();
        BigInteger SKA= SecKeyA.getS();
        ECPublicKey PubKeyA= (ECPublicKey)aKeyPair.getPublic();
        java.security.spec.ECPoint PUK=PubKeyA.getW();
        BigInteger pubByte = PUK.getAffineX();
        BigInteger pubByteY= PUK.getAffineY();

        ECPoint PUKA= curve.createPoint(PUK.getAffineX(),PUK.getAffineY());*/
        BigInteger SKA=new BigInteger("9ABA699E101051502AA8339C661C3F87097BDBE13B17D332A0315AA1",16);
        ECPoint PUKA=G.multiply(SKA);

        byte [] publicKeyA= PUKA.getEncoded(true);
        Log.i("APDUKEY","public key is "+utils.bytesToHex(publicKeyA));
        Log.i("APDUKEY","private key is "+utils.bytesToHex(utils.bytesFromBigInteger2(SKA)));
        byte[] publicKeyB= PUKA.getEncoded(false);
        publicKeyB=Arrays.copyOfRange(publicKeyB,1,publicKeyB.length);
        Log.i("APDU","I send "+utils.bytesToHex(publicKeyB));
        //publicKeyB = reverseByte(publicKeyB);
        int[] pubToC=utils.byteArrayToItArray(publicKeyB);
        byte[] skab=utils.bytesFromBigInteger2(SKA);
        Log.i("APDU","bytes is "+utils.bytesToHex(skab));
        Log.i("APDU","bytes is "+utils.bytesToHex(reverseByteShort(skab)));



       // int[] returned=giveBack(pubToC,GBC);
        byte[] rt= randPoint();
        //byte[] rt=utils.intArrtoByteArr(returned);
        Log.i(TAG,"I got back "+utils.bytesToHex(rt));
        rt=FixFromC56(rt);
        Log.i(TAG,"I got back "+utils.bytesToHex(rt));
        PUKA=PUKA.multiply(SKA);
        Log.i(TAG,"point is "+utils.bytesToHex(PUKA.getEncoded(false)));
        Log.i(TAG,"key for C is "+utils.bytesToHex(FixForC56(publicKeyB)));

        byte[] returned=giveBack(FixForC56(publicKeyB),utils.FixForC32(utils.bytesFromBigInteger2(SKA)));
        returned=FixFromC56(returned);
        Log.i(TAG,"point is"+utils.bytesToHex(returned));
        byte[] randPoint=randPoint2();
        byte[] randNum=randReturn(1);
        randPoint=utils.FixFromC56(randPoint);
        randNum=utils.FixForC32(randNum);
        Log.i(TAG,"random point that is 56bytes "+utils.bytesToHex(randPoint));
        Log.i(TAG,"random number is that should be 28bytes "+utils.bytesToHex(randNum));

    }
    public static byte [] fixForC28(byte[] toFix)
    {
        byte [] newByte= new byte[28];
        for(int i=0;i<28;i++)
        {
            newByte[i]=toFix[27-i];
        }
        return  newByte;
    }
    public static  byte[] FixForC56(byte[] toFix)
    {
        byte [] newByte= new byte[64];
        byte [] x=Arrays.copyOfRange(toFix,0,28);
        byte [] y= Arrays.copyOfRange(toFix,28,toFix.length);
        for(int i=0;i<28;i++)
        {
            newByte[i]=x[27-i];
        }
        for (int i=0;i<4;i++)
        {
            newByte[i+28]=(byte)0x00;
        }
        //Log.i("apdu","isa");
        for (int i=0;i<28;i++)
        {
            newByte[i+32]=y[27-i];
        }
        //Log.i("apdu","isa");
        for (int i=0;i<4;i++)
        {
            newByte[i+60]=(byte)0x00;
        }
        //Log.i("apdu","isa");
        return  newByte;
    }
    public static byte[] FixFromC56(byte[] toFix)
    {
        byte [] newByte= new byte[56];
        byte [] x=Arrays.copyOfRange(toFix,0,28);
        byte [] y= Arrays.copyOfRange(toFix,32,toFix.length-4);
        for(int i=0;i<28;i++)
        {
            newByte[i]=x[27-i];
        }
        for (int i=0;i<28;i++)
        {
            newByte[i+28]=y[27-i];
        }
        return  newByte;

    }
    public static byte[] reverseByte(byte[] reverseMe)
    {
        Log.i("APDU","lenbgt is "+reverseMe.length);
        byte [] newByte= new byte[reverseMe.length];
        int c=3;
        int ctr=0;
        int i=reverseMe.length/2-1;
        while(i>-1)
        {
            if (c==-1) {
                c=3;
                ctr=ctr+4;
            }
            newByte[i]=reverseMe[c+ctr];
            i--;
            c--;
        }
        i=reverseMe.length-1;
        ctr=reverseMe.length/2;
        c=3;
        while(i>reverseMe.length/2-1)
        {
            if (c==-1) {
                c=3;
                ctr=ctr+4;
            }
            newByte[i]=reverseMe[c+ctr];
            i--;
            c--;
        }

        return newByte;
    }
    public static byte[] reverseByteShort(byte[] reverseMe)
    {
        Log.i("APDU","lenbgt is "+reverseMe.length);
        byte [] newByte= new byte[reverseMe.length];
        int c=3;
        int ctr=0;
        int i=reverseMe.length-1;
        while(i>-1)
        {
            if (c==-1) {
                c=3;
                ctr=ctr+4;
            }
            newByte[i]=reverseMe[c+ctr];
            i--;
            c--;
        }
        return newByte;
    }
    public native byte[] giveBack(byte[] pubk, byte[] mul);
    public native byte[] randPoint2();
    public native byte[] randPoint();
    public native byte[]randReturn(int SecLevel);
}
