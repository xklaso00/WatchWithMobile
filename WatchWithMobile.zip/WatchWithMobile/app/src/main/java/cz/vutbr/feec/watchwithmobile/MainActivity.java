package cz.vutbr.feec.watchwithmobile;



//import android.support.v7.app.AppCompatActivity;
import android.content.BroadcastReceiver;
import android.os.Build;
import android.util.Log;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
//import android.support.v4.content.LocalBroadcastManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.gms.wearable.Node;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.android.gms.wearable.Wearable;

import java.io.IOException;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.concurrent.ExecutionException;


public class MainActivity extends AppCompatActivity {
    static {
        System.loadLibrary("native-lib");
    }
    String toSend=null;
    final static String TAG="MOBILE APP";

    TextView textview;
    Utils utils= new Utils();
    ECCOp eccOp=new ECCOp();
    byte [] hashToSign;
    byte[] randPoint;
    boolean recive=true;
    boolean recive1=true;
    long allTimeStart;
    long allTimeEnd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textview = findViewById(R.id.textView);
        IntentFilter messageFilter = new IntentFilter(Intent.ACTION_SEND);
        Receiver messageReceiver = new Receiver();
        LocalBroadcastManager.getInstance(this).registerReceiver(messageReceiver, messageFilter);

    }


    public class Receiver extends BroadcastReceiver {
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        public void onReceive(Context context, Intent intent) {
            if (recive==false)
                return;
            if (intent.getStringExtra("path").equals("1")){
                if (recive1==false)
                    return;
                else
                {
                    path1Response(intent);
                }

            }
            else if(intent.getStringExtra("path").equals("2")){
                if (recive==false)
                    return;
               else
                {
                    path2Response(intent);
                }
            }

        }
    }


    //thread to send message trough data layer
    class SendMessage extends Thread {
        String path;
        byte[] message;

        SendMessage(String p, byte[] m) {
            path = p;
            message = m;
        }

        public void run() {

            Task<List<Node>> wearableList = Wearable.getNodeClient(getApplicationContext()).getConnectedNodes();
            try {

                List<Node> nodes = Tasks.await(wearableList);
                for (Node node : nodes) {
                    Task<Integer> sendMessageTask = Wearable.getMessageClient(MainActivity.this).sendMessage(node.getId(), path, message);

                }

            } catch (ExecutionException exception) {
            }
            catch (InterruptedException exception) {
            }
            return;
        }
    }
    //what the program does when we get first  message from the watch
    public void path1Response(Intent intent){
        allTimeStart=System.nanoTime();
        recive1=false; //simple boolean so if anything is send more times this function will not be triggered
        randPoint=intent.getByteArrayExtra("message");
        Log.i(TAG,"Communication started...");
        Log.i(TAG,"Random point from watch is: "+utils.bytesToHex(randPoint));

        try {
            hashToSign=utils.generateHashToSend(randPoint,eccOp.givePub()); //generate hash that prover has to sign
            Log.i(TAG,"Hash for watch to sign is: "+utils.bytesToHex(hashToSign));
            //send the hash to watch with path 1
            new SendMessage("/path1", hashToSign).start();


            return;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //program does this after receiving second message from watch
    public void path2Response(Intent intent)
    {
        recive=false;
        byte[] signed = intent.getByteArrayExtra("message");
        BigInteger S= new BigInteger(1,signed);
        try {
            Log.i(TAG,"Signature from watch is: "+utils.bytesToHex(signed));
            long startTime=System.nanoTime();
            boolean isLegit=eccOp.signVer(S,randPoint,eccOp.givePub(),hashToSign); //ver in java for benchmark, will not be used in final app if verify on phone is needed
            long timeAll=System.nanoTime()-startTime;
            long start2=System.nanoTime();
            int[]pubInt=utils.byteArrayToItArray(utils.reverseByte(eccOp.givePubDecoded()));
            int[]signInt=utils.byteArrayToItArray(utils.reverseByte32(signed));
            int[]hashInt=utils.byteArrayToItArray(utils.reverseByte32(hashToSign));
            int [] randInt=utils.byteArrayToItArray(utils.reverseByte(eccOp.decodeEncoded(randPoint)));

            boolean isitlegitnow=verSignC(signInt,randInt,pubInt,hashInt); //verify in C, much faster
            long end2=System.nanoTime()-start2;
            //Log.i(TAG,"is it legit in C? "+isitlegitnow);
            Log.i(TAG, "In C verification took "+end2/1000000+"ms");
            Log.i(TAG,"In java verification took "+timeAll/1000000+"ms");
            Log.i(TAG,"Is the signature valid java and C? "+isLegit+isitlegitnow);
            allTimeEnd=System.nanoTime();
            Log.i(TAG,"Communication and verification took "+(allTimeEnd-allTimeStart)/1000000+"ms");
            textview.setText("Signature is here is it legit? "+isLegit);
            return;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public native boolean verSignC(int[] sign,int[] rand,int[] pub,int[]hash);
}
