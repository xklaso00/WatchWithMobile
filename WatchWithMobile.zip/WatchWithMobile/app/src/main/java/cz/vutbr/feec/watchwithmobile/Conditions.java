package cz.vutbr.feec.watchwithmobile;

public class Conditions {
    public static boolean GotIt=false;
    public static boolean GotRandWatch=false;
    public static boolean gotFirstLBM=false;
    public static boolean gotSecondLBM=false;
    public static boolean end=false;
    public static boolean gotRegister=false;
    public static boolean startedRegister=false;
    public static boolean readyToSendRegister=false;
    public static void Reset()
    {
        GotIt=false;
        GotRandWatch=false;
        gotFirstLBM=false;
        gotSecondLBM=false;
        end=false;

    }

}
